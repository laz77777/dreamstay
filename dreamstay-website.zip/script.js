
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('booking-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      alert('Booking confirmed! We will contact you soon.');
    });
  }
});
